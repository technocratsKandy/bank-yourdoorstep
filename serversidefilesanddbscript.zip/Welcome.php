<!DOCTYPE html>
<html>
<body>
<?php
echo "welcome ".$_SESSION["login_user"];
?>
</body>
</html>