-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2015 at 11:02 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bank_at_your_doorstep`
--

-- --------------------------------------------------------

--
-- Table structure for table `sys_appointments`
--

CREATE TABLE IF NOT EXISTS `sys_appointments` (
  `Appointment_id` int(100) NOT NULL,
  `User_Id` int(100) NOT NULL,
  `Offcial_Id` int(100) NOT NULL,
  `Start_Time` timestamp(6) NOT NULL,
  `End_Time` timestamp(6) NOT NULL,
  PRIMARY KEY (`Appointment_id`),
  KEY `User_Id` (`User_Id`),
  KEY `Offcial_Id` (`Offcial_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sys_kandy_user`
--

CREATE TABLE IF NOT EXISTS `sys_kandy_user` (
  `Kandy_User_Id` int(100) NOT NULL,
  `User_Id` int(100) NOT NULL,
  `API_Key` varchar(700) NOT NULL,
  `Kandy_Id` varchar(500) NOT NULL,
  `Kandy_Password` varchar(500) NOT NULL,
  PRIMARY KEY (`Kandy_User_Id`),
  KEY `User_Id` (`User_Id`),
  KEY `User_Id_2` (`User_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_kandy_user`
--

INSERT INTO `sys_kandy_user` (`Kandy_User_Id`, `User_Id`, `API_Key`, `Kandy_Id`, `Kandy_Password`) VALUES
(1, 1, 'DAKc16ba7264dd34b848dda50d75af37fc2', 'user1@zerolatency.gmail.com', '1exercitationemde1'),
(2, 2, 'DAKc16ba7264dd34b848dda50d75af37fc2', 'user2@zerolatency.gmail.com', '2necessitatibusvo2'),
(3, 3, 'DAK198cc096c4a645a2b32dc2b21736f47a', 'user1@technocrats.gmail.com', '1odioeatenetur1'),
(4, 4, 'DAK198cc096c4a645a2b32dc2b21736f47a', 'user2@technocrats.gmail.com', '2quiaadipisciut2');

-- --------------------------------------------------------

--
-- Table structure for table `sys_roles`
--

CREATE TABLE IF NOT EXISTS `sys_roles` (
  `Role_id` int(100) NOT NULL,
  `Role_Type` varchar(500) NOT NULL,
  PRIMARY KEY (`Role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_roles`
--

INSERT INTO `sys_roles` (`Role_id`, `Role_Type`) VALUES
(1, 'Customer'),
(2, 'Bank_Official');

-- --------------------------------------------------------

--
-- Table structure for table `sys_users`
--

CREATE TABLE IF NOT EXISTS `sys_users` (
  `User_id` int(100) NOT NULL,
  `User_name` varchar(500) NOT NULL,
  `Password` varchar(500) NOT NULL,
  `Role` int(100) NOT NULL,
  PRIMARY KEY (`User_id`),
  KEY `Role` (`Role`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_users`
--

INSERT INTO `sys_users` (`User_id`, `User_name`, `Password`, `Role`) VALUES
(1, 'Laxmi', 'Laxkan', 1),
(2, 'Neelesh', 'Nelaro', 1),
(3, 'Saurabh', 'Saugad', 2),
(4, 'Hemal', 'Hempan', 2);

-- --------------------------------------------------------

--
-- Table structure for table `sys_user_details`
--

CREATE TABLE IF NOT EXISTS `sys_user_details` (
  `User_id` int(100) NOT NULL,
  `Address` text NOT NULL,
  `Email_Id` varchar(100) NOT NULL,
  `Phone_Number` double NOT NULL,
  KEY `User_id` (`User_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_user_details`
--

INSERT INTO `sys_user_details` (`User_id`, `Address`, `Email_Id`, `Phone_Number`) VALUES
(1, 'Megapolis,Sunway A18 703', 'lk00327054@techmahindra.com', 9767251009),
(2, 'Megapolis,Sunway A07 1304', 'lk00327054@techmahindra.com', 9767251009),
(3, 'Megapolis,Sunway A07 1304', 'lk00327054@techmahindra.com', 9767251009),
(4, 'Megapolis,Sunway A07 1304', 'lk00327054@techmahindra.com', 9767251009);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sys_appointments`
--
ALTER TABLE `sys_appointments`
  ADD CONSTRAINT `User_id_Foreign_Key_Ctr1` FOREIGN KEY (`Offcial_Id`) REFERENCES `sys_users` (`User_id`),
  ADD CONSTRAINT `User_id_Foreign_Key_Ctr` FOREIGN KEY (`User_Id`) REFERENCES `sys_users` (`User_id`);

--
-- Constraints for table `sys_kandy_user`
--
ALTER TABLE `sys_kandy_user`
  ADD CONSTRAINT `sys_kandy_user_ibfk_1` FOREIGN KEY (`User_Id`) REFERENCES `sys_users` (`User_id`);

--
-- Constraints for table `sys_user_details`
--
ALTER TABLE `sys_user_details`
  ADD CONSTRAINT `User_Id_Foreign_Key` FOREIGN KEY (`User_id`) REFERENCES `sys_users` (`User_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
